// DAO/MonthlyReportDAO.java
package DAO;

import Model.MonthlyReport;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MonthlyReportDAO {
    private Connection connection;

    public MonthlyReportDAO(Connection connection) {
        this.connection = connection;
    }

    public List<MonthlyReport> getReportsForMonth(String month) throws SQLException {
        List<MonthlyReport> reports = new ArrayList<>();
        String query = "SELECT * FROM monthly_reports WHERE month = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, month);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MonthlyReport report = new MonthlyReport();
                report.setSpareParts(resultSet.getString("spare_parts"));
                report.setServices(resultSet.getString("services"));
                report.setSaleTrends(resultSet.getString("sale_trends"));
                report.setTopSellingItems(resultSet.getString("top_selling_items"));
                report.setMonth(resultSet.getString("month"));
                report.setImprovements(resultSet.getString("improvements"));
                reports.add(report);
            }
        }
        return reports;
    }

    public void generateReport(MonthlyReport report) throws SQLException {
        String query = "INSERT INTO monthly_reports (spare_parts, services, sale_trends, top_selling_items, month, improvements) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, report.getSpareParts());
            statement.setString(2, report.getServices());
            statement.setString(3, report.getSaleTrends());
            statement.setString(4, report.getTopSellingItems());
            statement.setString(5, report.getMonth());
            statement.setString(6, report.getImprovements());
            statement.executeUpdate();
        }
    }
}
