// Controller/MonthlyReportController.java
package Controller;

import DAO.MonthlyReportDAO;
import Model.MonthlyReport;
import Utils.DBConnector;
import Views.MonthlyReportView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class MonthlyReportController {
    private MonthlyReportView view;
    private MonthlyReportDAO reportDAO;

    public MonthlyReportController(MonthlyReportView view) {
        this.view = view;
        try {
            Connection connection = DBConnector.getConnection();
            this.reportDAO = new MonthlyReportDAO(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        this.view.addGenerateReportListener(new GenerateReportListener());
        this.view.addGetReportsFromMonthListener(new GetReportsFromMonthListener());
    }

    class GenerateReportListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            MonthlyReport report = new MonthlyReport();
            report.setSpareParts(view.getSparePartsText());
            report.setServices(view.getServicesText());
            report.setSaleTrends(view.getSaleTrendsText());
            report.setTopSellingItems(view.getTopSellingItemsText());
            report.setMonth(view.getMonthText());
            report.setImprovements(view.getImprovementsText());

            try {
                reportDAO.generateReport(report);
                JOptionPane.showMessageDialog(null, "Report generated successfully!");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error generating report!");
            }
        }
    }

    class GetReportsFromMonthListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String month = view.getEnterMonthText();
            try {
                List<MonthlyReport> reports = reportDAO.getReportsForMonth(month);
                view.displayReports(reports);
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error retrieving reports!");
            }
        }
    }
}
