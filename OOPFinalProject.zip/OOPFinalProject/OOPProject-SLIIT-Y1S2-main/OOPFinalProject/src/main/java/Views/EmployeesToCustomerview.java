package Views;

import javax.swing.*;

public class EmployeesToCustomerview {
    private JButton getAvailableEmployeesButton;
    private JTable table1;
    private JTextField enterNameTextField;
    private JButton assignJobButton;
    private JTextField enterCustomerNameTextField;
}
