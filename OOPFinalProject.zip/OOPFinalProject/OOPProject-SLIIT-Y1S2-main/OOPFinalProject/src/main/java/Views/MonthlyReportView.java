// Views/MonthlyReportView.java
package Views;

import Model.MonthlyReport;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MonthlyReportView extends JFrame {
    private JTextField sparePartsField;
    private JTextField servicesField;
    private JTextField saleTrendsField;
    private JTextField topSellingItemsField;
    private JTextField monthField;
    private JButton generateReportButton;
    private JButton getReportsFromMonthButton;
    private JTextField enterMonthTextField;
    private JTable table1;
    private JTextArea improvementsArea;

    public MonthlyReportView() {
        setTitle("Monthly Report");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(0, 2));

        sparePartsField = new JTextField();
        servicesField = new JTextField();
        saleTrendsField = new JTextField();
        topSellingItemsField = new JTextField();
        monthField = new JTextField();
        enterMonthTextField = new JTextField();
        improvementsArea = new JTextArea();
        generateReportButton = new JButton("Generate Report");
        getReportsFromMonthButton = new JButton("Get Reports for Month");
        table1 = new JTable();

        add(new JLabel("Spare Parts:"));
        add(sparePartsField);
        add(new JLabel("Services:"));
        add(servicesField);
        add(new JLabel("Sale Trends:"));
        add(saleTrendsField);
        add(new JLabel("Top Selling Items:"));
        add(topSellingItemsField);
        add(new JLabel("Month:"));
        add(monthField);
        add(new JLabel("Improvements:"));
        add(new JScrollPane(improvementsArea));
        add(generateReportButton);
        add(new JLabel("Enter Month:"));
        add(enterMonthTextField);
        add(getReportsFromMonthButton);
        add(new JScrollPane(table1));

        setVisible(true);
    }

    public String getSparePartsText() {
        return sparePartsField.getText();
    }

    public String getServicesText() {
        return servicesField.getText();
    }

    public String getSaleTrendsText() {
        return saleTrendsField.getText();
    }

    public String getTopSellingItemsText() {
        return topSellingItemsField.getText();
    }

    public String getMonthText() {
        return monthField.getText();
    }

    public String getEnterMonthText() {
        return enterMonthTextField.getText();
    }

    public String getImprovementsText() {
        return improvementsArea.getText();
    }

    public void addGenerateReportListener(ActionListener listener) {
        generateReportButton.addActionListener(listener);
    }

    public void addGetReportsFromMonthListener(ActionListener listener) {
        getReportsFromMonthButton.addActionListener(listener);
    }

    public void displayReports(List<MonthlyReport> reports) {
        String[] columnNames = {"Spare Parts", "Services", "Sale Trends", "Top Selling Items", "Month", "Improvements"};
        String[][] data = new String[reports.size()][6];
        for (int i = 0; i < reports.size(); i++) {
            MonthlyReport report = reports.get(i);
            data[i][0] = report.getSpareParts();
            data[i][1] = report.getServices();
            data[i][2] = report.getSaleTrends();
            data[i][3] = report.getTopSellingItems();
            data[i][4] = report.getMonth();
            data[i][5] = report.getImprovements();
        }
        table1.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }
}

