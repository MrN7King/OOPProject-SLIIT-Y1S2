package Views;

import javax.swing.*;

public class ManageEmployeesView {
    private JButton getAllEmployeesButton;
    private JButton getOfficeEmployeesButton;
    private JButton getShipEmployeesButton;
    private JButton getFieldEmployeesButton;
    private JTable table1;
}
