package Views;

import javax.swing.*;

public class ManageCustomerOrderView {
    private JScrollPane CustomerTable;
    private JTable table1;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JCheckBox sparePartsCheckBox;
    private JCheckBox repaintingCheckBox;
    private JCheckBox repairsCheckBox;
    private JButton AddCustomerButton;
}
