package Views;

import javax.swing.*;

public class ManageSuppilerView {
    private JTextField SupplierName;
    private JTextField SupplierID;
    private JTextField PartID;
    private JTextField SupplierContact;
    private JButton addButton;
    private JTextField UpdateID;
    private JTextField UpdateName;
    private JTextField UpdatePart;
    private JTextField UpdateContact;
    private JButton updateButton;
    private JTextField RemoveID;
    private JButton removeButton;
    private JTable table1;
}
