package Views;

public class ManageInventoryView {
}
