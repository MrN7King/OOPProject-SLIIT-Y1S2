// Model/MonthlyReport.java
package Model;

public class MonthlyReport {
    private String spareParts;
    private String services;
    private String saleTrends;
    private String topSellingItems;
    private String month;
    private String improvements;

    // Getters and Setters
    public String getSpareParts() {
        return spareParts;
    }

    public void setSpareParts(String spareParts) {
        this.spareParts = spareParts;
    }

    public String getServices() {
        return services;
    }

    public void setServices(String services) {
        this.services = services;
    }

    public String getSaleTrends() {
        return saleTrends;
    }

    public void setSaleTrends(String saleTrends) {
        this.saleTrends = saleTrends;
    }

    public String getTopSellingItems() {
        return topSellingItems;
    }

    public void setTopSellingItems(String topSellingItems) {
        this.topSellingItems = topSellingItems;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getImprovements() {
        return improvements;
    }

    public void setImprovements(String improvements) {
        this.improvements = improvements;
    }
}
